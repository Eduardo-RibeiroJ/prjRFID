﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;
using rfidDAL;
using ThingMagic;

namespace RFID
{
    public partial class CWRFID : Form
    {
        
        static DAL dal = new DAL();
        static Reader reader = dal.conectarLeitor("tmr://192.168.1.101/");
        
        public CWRFID()
        {
            InitializeComponent();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            Etiqueta obj = new Etiqueta();
            obj.etiqueta = txtInserir.Text;
            DAL dal = new DAL();
            try
            {
                dal.Inserir(obj);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw ex;
            }
            finally
            {
                MessageBox.Show("OK!");
            }
        }

        public void OnTagRead(object sender, TagReadDataEventArgs e)
        {
            Etiqueta tag = new Etiqueta();
            tag.Antena = e.TagReadData.Antenna;
            tag.etiqueta = e.TagReadData.EpcString;
            tag.Horario = e.TagReadData.Time;

            DAL dal = new DAL();
            dal.Inserir(tag);
        }

        private void BtnIniciar_Click(object sender, EventArgs e)
        {
            DAL dal = new DAL();
            dal.setPower(reader, 2300);
            reader.TagRead += OnTagRead;
        }

        private void BtnPararLeitura_Click(object sender, EventArgs e)
        {
            reader.StopReading();
        }

        private void CWRFID_Load(object sender, EventArgs e)
        {
        }
    }
}
