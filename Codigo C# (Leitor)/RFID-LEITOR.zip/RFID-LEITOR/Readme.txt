M�todo C# para inser��o no banco de dados MySQL c/ um form para teste.
Para compilar precisa instalar o conector mysql na DAL e na Models via 
NU-GET Package Manager Console do Visual Studio com o comando:
Install-Package MySQL.Data
