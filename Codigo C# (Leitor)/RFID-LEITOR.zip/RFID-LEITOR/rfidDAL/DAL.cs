﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using MySql.Data.MySqlClient;
using System.Configuration;
using ThingMagic;
using System.IO;

namespace rfidDAL
{
    public class DAL
    {

        //  STRING DE CONEXAO, É SO EDITAR USUARIO E SENHA
        MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bd_rfid;Uid=rfid;Pwd=");
        //MÉTODO PARA INSERIR NO MYSQL
        public void Inserir(Etiqueta e)
        {
            try
            {
                conn.Open();
                string sql = "INSERT INTO tbTemp (etiqueta) VALUES ( @etiqueta );";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@etiqueta", e.etiqueta);
                cmd.ExecuteNonQuery();
            } catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }


        public Reader conectarLeitor(String uri)
        {
            Reader reader = Reader.Create(uri);

            try
            {
                reader.Connect();
                string[] list = reader.ParamList();
                Reader.Region[] regions = (Reader.Region[])reader.ParamGet("/reader/region/supportedRegions");
                reader.ParamSet(list[37], Reader.Region.NA);
                return reader;
            }
            catch (IOException e)
            {
                throw e;
            }
        }

        public void setPower(Reader reader, int power)
        {
            reader.ParamSet("/reader/radio/readPower", power);
        }

    }
}
