﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace rfidDAL
{
    public class DAL
    {

        //  STRING DE CONEXAO, É SO EDITAR USUARIO E SENHA
        MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bd_rfid;Uid=rfid;Pwd=");
        //MÉTODO PARA INSERIR NO MYSQL
        public void Inserir(Etiqueta e)
        {
            try
            {
                conn.Open();
                string sql = "INSERT INTO tbTemp (etiqueta) VALUES ( @etiqueta );";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@etiqueta", e.etiqueta);
                cmd.ExecuteNonQuery();
            } catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }

               
    }
}
