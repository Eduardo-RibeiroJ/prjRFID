﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;
using rfidDAL;

namespace RFID
{
    public partial class RFID : Form
    {
        public RFID()
        {
            InitializeComponent();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            Etiqueta obj = new Etiqueta();
            obj.etiqueta = txtInserir.Text;
            DAL dal = new DAL();
            try
            {
                dal.Inserir(obj);
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw ex;                                   
            }
            finally
            {
                MessageBox.Show("OK!");
            }
        }
    }
}
